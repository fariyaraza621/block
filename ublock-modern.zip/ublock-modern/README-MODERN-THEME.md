# uBlock Origin Modern Theme

A modern, sleek user interface theme for uBlock Origin based on the original uBlock Origin source code.

## Features

### 🎨 Modern Design
- **Dark Theme First**: Beautiful dark color palette with purple accents
- **Glassmorphism Effects**: Subtle gradients and backdrop blur effects
- **Smooth Animations**: Polished transitions and hover effects
- **Custom Scrollbars**: Styled scrollbars matching the theme

### ✨ Enhanced UI Components
- **Power Button**: Glowing effect with hover animations
- **Modern Toggle Switches**: iOS-style toggle switches with gradient fills
- **Card-based Layout**: Rounded corners with subtle shadows
- **Enhanced Buttons**: Gradient primary buttons with hover lift effect
- **Styled Input Fields**: Modern form inputs with focus states

### 🌐 Responsive & Accessible
- **Light Mode Support**: Automatically adapts to system light mode preference
- **Mobile Optimized**: Responsive design for smaller screens
- **Reduced Motion**: Respects user's reduced motion preferences
- **Focus Visible**: Clear focus indicators for keyboard navigation

### 📊 Visual Enhancements
- **Stats Display**: Highlighted statistics with hover effects
- **Domain List**: Hover highlights for firewall/domain rows
- **Tooltip Improvements**: Enhanced tooltip styling
- **Badge Styles**: Modern badge design for notifications

## Installation

### For Development
1. Clone the repository:
   ```bash
   git clone https://github.com/gorhill/uBlock.git ublock-modern
   cd ublock-modern/src/css
   ```

2. The modern theme CSS is already included as `modern-theme.css`

3. The theme is automatically loaded in all major HTML files:
   - popup-fenix.html (popup panel)
   - dashboard.html (settings dashboard)
   - settings.html
   - 3p-filters.html
   - logger-ui.html
   - And more...

### Loading in Browser (Development Mode)

#### Chrome/Chromium
1. Open `chrome://extensions/`
2. Enable "Developer mode"
3. Click "Load unpacked"
4. Navigate to the `platform/mv3/chromium` directory
5. Select the folder and load

#### Firefox
1. Open `about:debugging#/runtime/this-firefox`
2. Click "Load Temporary Add-on"
3. Navigate to the extension directory
4. Select any file in the manifest.json directory

## Customization

You can customize the theme by editing `/src/css/modern-theme.css`:

### Color Variables
```css
:root {
    --surface-0: #0f0f12;      /* Darkest background */
    --surface-1: #1a1a2e;      /* Main background */
    --surface-2: #252542;      /* Card background */
    --primary-40: 129, 140, 248; /* Primary accent color (RGB) */
    /* ... more variables ... */
}
```

### Animation Speed
```css
--transition-fast: 150ms;
--transition-base: 250ms;
--transition-slow: 350ms;
```

### Border Radius
```css
--radius-sm: 6px;
--radius-md: 10px;
--radius-lg: 14px;
--radius-xl: 20px;
```

## File Structure

```
ublock-modern/
├── src/
│   ├── css/
│   │   ├── modern-theme.css    # ← Modern theme styles
│   │   ├── common.css          # Base styles
│   │   ├── popup-fenix.css     # Popup styles
│   │   └── ...
│   ├── popup-fenix.html        # Main popup
│   ├── dashboard.html          # Settings dashboard
│   └── ...
└── platform/
    └── mv3/
        ├── chromium/           # Chrome version
        └── firefox/            # Firefox version
```

## Browser Compatibility

- ✅ Chrome/Chromium 122+
- ✅ Firefox 128+
- ✅ Edge (Chromium-based)
- ⚠️ Safari (limited support, may need adjustments)

## Credits

- **Base Project**: [uBlock Origin](https://github.com/gorhill/uBlock) by Raymond Hill
- **Theme Author**: Modern Theme Implementation
- **Icons**: Font Awesome (included in uBlock Origin)

## License

This theme inherits the license from uBlock Origin (GPLv3).

## Contributing

Feel free to customize and improve the theme! Key areas for enhancement:
- Additional color schemes (blue, green, red themes)
- More animation options
- Custom icon sets
- Additional accessibility improvements

---

**Note**: This is a UI theme modification. All blocking functionality remains unchanged from the original uBlock Origin.
